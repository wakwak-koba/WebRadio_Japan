esptool.exe --chip esp32s3 --port COM1 --baud 921600 --before default_reset --after hard_reset write_flash -z --flash_mode dio --flash_freq 80m --flash_size 4MB 0x0000 WebRadio_ListenRadio.ino.bootloader.bin 0x8000 WebRadio_ListenRadio.ino.partitions.bin 0xe000 boot_app0.bin 0x10000 WebRadio_ListenRadio.ino.bin
timeout 5
